# RIYA FITNESS⚡ Android app starter

## Included
- Dark + neon green mobile UI
- Offline-first dashboard
- Manual running/walking/cycling logs, distance, duration, steps
- Estimated calories
- Water glass counter
- Workout routines and custom routines
- Daily/weekly progress, badges, BMI calculator
- Local browser storage and JSON backup export/import
- Optional notification permission prompt and in-app water reminder timer

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder as an existing Gradle project.
3. Let Gradle sync and install Android SDK 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will usually be at `app/build/outputs/apk/debug/app-debug.apk`.

## Important limitations
This is a working starter project, not a signed Play Store release. It does not automatically access the phone's step sensor, GPS, heart-rate sensors, or run background reminders when the app is closed. Activities and reminders are mostly manual and saved locally on this device. Test before relying on any health estimate.
